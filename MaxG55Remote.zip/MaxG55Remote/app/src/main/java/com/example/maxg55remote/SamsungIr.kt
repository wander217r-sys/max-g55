package com.example.maxg55remote

/**
 * Codificador Samsung32 (portadora 38 kHz).
 * Trama: cabecera 4500/4500 µs + 32 bits + marca final.
 *
 * Dos formas de describir el mismo código (ejemplo: POWER de un TV Samsung):
 *  - Notación "en el aire" 0xE0E040BF -> los bits salen tal cual, MSB primero.
 *  - Notación estándar (Flipper/IRDB) dirección 0x07, comando 0x02
 *    -> se envía [dir, dir, cmd, ~cmd] con LSB primero.
 * Ambas producen exactamente la misma señal.
 */
object SamsungIr {
    const val CARRIER_HZ = 38000
    private const val HDR_MARK = 4500
    private const val HDR_SPACE = 4500
    private const val BIT_MARK = 560
    private const val ONE_SPACE = 1690
    private const val ZERO_SPACE = 560

    private fun build(bytes: IntArray, msbFirst: Boolean): IntArray {
        val p = ArrayList<Int>(70)
        p += HDR_MARK; p += HDR_SPACE
        for (b in bytes) {
            val order = if (msbFirst) 7 downTo 0 else 0..7
            for (i in order) {
                p += BIT_MARK
                p += if ((b shr i) and 1 == 1) ONE_SPACE else ZERO_SPACE
            }
        }
        p += BIT_MARK
        return p.toIntArray()
    }

    /** Formato 0xAABBCCDD (notación "en el aire", MSB primero). */
    fun encodeWire(b0: Int, b1: Int, b2: Int, b3: Int): IntArray =
        build(intArrayOf(b0, b1, b2, b3), msbFirst = true)

    /** Formato estándar: dirección y comando (LSB primero, comando repetido invertido). */
    fun encodeStandard(address: Int, command: Int): IntArray =
        build(intArrayOf(address and 0xFF, address and 0xFF, command and 0xFF, command.inv() and 0xFF), msbFirst = false)
}
