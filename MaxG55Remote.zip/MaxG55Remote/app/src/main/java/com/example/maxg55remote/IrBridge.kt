package com.example.maxg55remote

import android.hardware.ConsumerIrManager
import android.webkit.JavascriptInterface

/** Puente JS → emisor IR. En JS se usa como window.AndroidIR */
class IrBridge(private val ir: ConsumerIrManager?) {

    @JavascriptInterface
    fun hasEmitter(): Boolean = ir?.hasIrEmitter() == true

    /** hex en notación "en el aire", ej: "0xE0E040BF". Devuelve: ok | warn_checksum | bad_hex | no_emitter | error */
    @JavascriptInterface
    fun send(hex: String): String {
        val mgr = ir
        if (mgr == null || !mgr.hasIrEmitter()) return "no_emitter"
        val v = hex.trim().removePrefix("0x").removePrefix("0X")
        if (v.length != 8 || !v.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return "bad_hex"
        return try {
            val n = v.toLong(16)
            val b0 = ((n shr 24) and 0xFF).toInt()
            val b1 = ((n shr 16) and 0xFF).toInt()
            val b2 = ((n shr 8) and 0xFF).toInt()
            val b3 = (n and 0xFF).toInt()
            mgr.transmit(SamsungIr.CARRIER_HZ, SamsungIr.encodeWire(b0, b1, b2, b3))
            if ((b2 xor b3) == 0xFF) "ok" else "warn_checksum"
        } catch (e: Exception) {
            "error"
        }
    }

    /** Dirección/comando estándar Samsung32 (como en Flipper-IRDB). Usado por el explorador. */
    @JavascriptInterface
    fun sendAC(address: Int, command: Int): String {
        val mgr = ir
        if (mgr == null || !mgr.hasIrEmitter()) return "no_emitter"
        return try {
            mgr.transmit(SamsungIr.CARRIER_HZ, SamsungIr.encodeStandard(address, command))
            "ok"
        } catch (e: Exception) {
            "error"
        }
    }
}
