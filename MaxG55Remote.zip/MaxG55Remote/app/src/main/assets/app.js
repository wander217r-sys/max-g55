// Base de 37 comandos IR (formato 0xAABBCCDD, orden de transmisión AA BB CC DD).
// ⚠️ SIN VERIFICAR: pruébalos con el equipo y corrige los que no funcionen
// con el "Modo edición" (se guardan en el teléfono, no hace falta recompilar).
const codigosSamsung = {
    // Energía y Fuentes
    'POWER': '0xE0E040BF',
    'SRC_TUNER': '0x4040629D',
    'SRC_CD': '0x404012ED',
    'SRC_USB': '0x404022DD',
    'SRC_AUX': '0x4040A25D',

    // Teclado Numérico
    'NUM_1': '0xE0E020DF',
    'NUM_2': '0xE0E0A05F',
    'NUM_3': '0xE0E0609F',
    'NUM_4': '0xE0E010EF',
    'NUM_5': '0xE0E0906F',
    'NUM_6': '0xE0E050AF',
    'NUM_7': '0xE0E030CF',
    'NUM_8': '0xE0E0B04F',
    'NUM_9': '0xE0E0708F',
    'NUM_10_PLUS': '0x404052AD',
    'NUM_0': '0xE0E08877',
    'ENTER': '0xE0E016E9',

    // Volumen y Navegación / Sintonía
    'VOL_UP': '0xE0E0E01F',
    'MUTE': '0xE0E0F00F',
    'VOL_DOWN': '0xE0E0D02F',
    'NAV_UP': '0xE0E006F9',
    'NAV_DOWN': '0xE0E08679',
    'NAV_LEFT': '0xE0E0A659',
    'NAV_RIGHT': '0xE0E046B9',
    'NAV_OK': '0x4040F20D',

    // Reproducción y Opciones
    'MEDIA_PREV': '0x404002FD',
    'MEDIA_PLAY': '0xE0E0E21D',
    'MEDIA_PAUSE': '0x404052AF',
    'MEDIA_STOP': '0x404012ED',
    'MEDIA_NEXT': '0x4040827D',
    'PLAY_MODE': '0x4040926D',
    'REPEAT': '0x4040D22D',
    'DISPLAY': '0x404032CD',

    // Audio avanzado y reloj
    'P_EQ': '0x4040728D',
    'GigaSound': '0x4040B24D',
    'SLEEP': '0x404006F9',
    'TIMER': '0x40408679',
    'CLOCK': '0x404046B9',
    'DEMO': '0x4040C639'
};

const STORAGE_KEY = 'codigosPersonalizados';
const REPETIBLES = new Set(['VOL_UP', 'VOL_DOWN', 'NAV_LEFT', 'NAV_RIGHT']);
let modoEdicion = false;
let claveEditando = null;

function leerOverrides() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch (e) { return {}; }
}
function guardarOverrides(o) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(o)); } catch (e) {}
}
function codigoDe(boton) { return leerOverrides()[boton] || codigosSamsung[boton]; }

let toastTimer;
function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 1400);
}

function enviarSenal(boton, silencioso) {
    const hex = codigoDe(boton);
    if (!hex) { toast('Sin código para ' + boton); return; }
    if (!window.AndroidIR) {
        if (!silencioso) toast('Vista previa: ' + boton + ' → ' + hex);
        return;
    }
    const r = window.AndroidIR.send(hex);
    if (silencioso && r === 'ok') return;
    if (r === 'ok') toast(boton + ' ✔');
    else if (r === 'warn_checksum') toast(boton + ' enviado, pero el código parece inválido (checksum)');
    else if (r === 'bad_hex') toast('Código mal escrito: ' + hex);
    else if (r === 'no_emitter') toast('Este teléfono no tiene emisor IR');
    else toast('Error al enviar ' + boton);
}

// ---- Modal de edición ----
function abrirEditor(clave) {
    claveEditando = clave;
    document.getElementById('modal-titulo').textContent = 'Código de ' + clave;
    document.getElementById('modal-actual').textContent =
        'Actual: ' + codigoDe(clave) + '  |  Original: ' + codigosSamsung[clave];
    const inp = document.getElementById('modal-input');
    inp.value = codigoDe(clave);
    document.getElementById('modal').hidden = false;
}
function cerrarEditor() { document.getElementById('modal').hidden = true; claveEditando = null; }

function guardarEditor() {
    let v = document.getElementById('modal-input').value.trim();
    v = v.replace(/^0x/i, '');
    if (!/^[0-9a-fA-F]{8}$/.test(v)) { toast('Usa 8 dígitos hex, ej: 0xE0E040BF'); return; }
    const o = leerOverrides();
    o[claveEditando] = '0x' + v.toUpperCase();
    guardarOverrides(o);
    const k = claveEditando;
    cerrarEditor();
    toast('Guardado ' + k);
    enviarSenal(k, true); // lo prueba al instante
}
function restaurarEditor() {
    const o = leerOverrides();
    delete o[claveEditando];
    guardarOverrides(o);
    cerrarEditor();
    toast('Restaurado');
}

// ---- Inicio ----
document.addEventListener('DOMContentLoaded', () => {
    const estado = document.getElementById('estado');
    if (window.AndroidIR) {
        if (window.AndroidIR.hasEmitter()) { estado.textContent = 'Emisor IR detectado ✔'; estado.className = 'estado ok'; }
        else { estado.textContent = 'Este teléfono no tiene emisor IR ✖'; estado.className = 'estado mal'; }
    } else {
        estado.textContent = 'Vista previa en navegador (sin IR)'; estado.className = 'estado';
    }

    document.querySelectorAll('button[onclick]').forEach(btn => {
        const m = /enviarSenal\('([^']+)'\)/.exec(btn.getAttribute('onclick'));
        if (!m) return;
        const clave = m[1];
        btn.removeAttribute('onclick');
        btn.dataset.key = clave;

        let tRep = null, iRep = null, repitio = false;
        const parar = () => { clearTimeout(tRep); clearInterval(iRep); };

        btn.addEventListener('pointerdown', () => {
            repitio = false;
            if (!modoEdicion && REPETIBLES.has(clave)) {
                tRep = setTimeout(() => {
                    repitio = true;
                    enviarSenal(clave, true);
                    iRep = setInterval(() => enviarSenal(clave, true), 150);
                }, 400);
            }
        });
        ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => btn.addEventListener(ev, parar));

        btn.addEventListener('click', () => {
            if (repitio) { repitio = false; return; }
            if (modoEdicion) abrirEditor(clave); else enviarSenal(clave);
        });
    });

    const be = document.getElementById('btn-edit');
    be.addEventListener('click', () => {
        modoEdicion = !modoEdicion;
        document.body.classList.toggle('editando', modoEdicion);
        be.classList.toggle('on', modoEdicion);
        be.textContent = '✎ Modo edición de códigos: ' + (modoEdicion ? 'ON (toca un botón)' : 'OFF');
    });

    document.getElementById('modal-guardar').addEventListener('click', guardarEditor);
    document.getElementById('modal-reset').addEventListener('click', restaurarEditor);
    document.getElementById('modal-cancelar').addEventListener('click', cerrarEditor);
});

// ================= Explorador de códigos =================
function rev8(b) { let r = 0; for (let i = 0; i < 8; i++) r = (r << 1) | ((b >> i) & 1); return r; }
function h2(n) { return n.toString(16).toUpperCase().padStart(2, '0'); }
// dirección/comando estándar (Flipper) -> notación 0xAABBCCDD usada en la tabla
function hexDesdeAC(a, c) {
    return '0x' + h2(rev8(a)) + h2(rev8(a)) + h2(rev8(c)) + h2(rev8((~c) & 255));
}
function parseHex2(s) { const v = parseInt((s || '').trim(), 16); return (isNaN(v) || v < 0 || v > 255) ? null : v; }

document.addEventListener('DOMContentLoaded', () => {
    const $ = id => document.getElementById(id);
    const addrIn = $('sc-addr'), cmdIn = $('sc-cmd'), info = $('sc-info'), sel = $('sc-key');
    let autoTimer = null;

    Object.keys(codigosSamsung).forEach(k => {
        const o = document.createElement('option'); o.value = k; o.textContent = k; sel.appendChild(o);
    });

    function leer() {
        const a = parseHex2(addrIn.value), c = parseHex2(cmdIn.value);
        if (a === null || c === null) { toast('Usa 2 dígitos hex (00–FF)'); return null; }
        return { a, c };
    }
    function enviarActual() {
        const v = leer(); if (!v) return false;
        info.textContent = 'Dir ' + h2(v.a) + '  Cmd ' + h2(v.c) + '  →  ' + hexDesdeAC(v.a, v.c);
        if (window.AndroidIR) window.AndroidIR.sendAC(v.a, v.c);
        return true;
    }
    function paso(d) {
        const v = leer(); if (!v) return;
        cmdIn.value = h2((v.c + d + 256) % 256);
        enviarActual();
    }
    function detenerAuto() {
        if (autoTimer) { clearInterval(autoTimer); autoTimer = null; }
        $('sc-auto').textContent = 'Auto';
    }

    $('sc-send').addEventListener('click', enviarActual);
    $('sc-prev').addEventListener('click', () => { detenerAuto(); paso(-1); });
    $('sc-next').addEventListener('click', () => { detenerAuto(); paso(1); });
    $('sc-addr-02').addEventListener('click', () => { addrIn.value = '02'; cmdIn.value = '00'; });
    $('sc-addr-07').addEventListener('click', () => { addrIn.value = '07'; cmdIn.value = '00'; });
    $('sc-addr-next').addEventListener('click', () => {
        const a = parseHex2(addrIn.value); if (a === null) return;
        detenerAuto(); addrIn.value = h2((a + 1) % 256); cmdIn.value = '00';
    });

    $('sc-auto').addEventListener('click', () => {
        if (autoTimer) { detenerAuto(); toast('Detenido en cmd ' + cmdIn.value); return; }
        $('sc-auto').textContent = 'Stop';
        autoTimer = setInterval(() => {
            const v = leer(); if (!v) { detenerAuto(); return; }
            enviarActual();
            if (v.c === 255) { detenerAuto(); toast('Fin de comandos para esta dirección'); return; }
            cmdIn.value = h2(v.c + 1);
        }, 700);
    });

    $('sc-assign').addEventListener('click', () => {
        const v = leer(); if (!v) return;
        const k = sel.value, hex = hexDesdeAC(v.a, v.c);
        const o = leerOverrides(); o[k] = hex; guardarOverrides(o);
        toast(k + ' = ' + hex + ' guardado');
    });
});
